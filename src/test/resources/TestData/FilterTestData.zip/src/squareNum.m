function out = squareNum(number)
%SQNUM Summary of this function goes here
%   Detailed explanation goes here
 out = number * number;
end

