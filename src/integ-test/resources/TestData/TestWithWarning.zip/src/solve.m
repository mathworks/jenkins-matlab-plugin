function x = solve(A,b)

assert(abs(det(A)) > 1e-12,... % intentional bug for illustrative purposes
    'The matrix is singular or nearly singular'); 

x = A\b;