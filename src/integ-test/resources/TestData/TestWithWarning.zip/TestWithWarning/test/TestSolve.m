classdef TestSolve < matlab.unittest.TestCase
    
    methods(Test)
        function testOne(testCase)
            A = eye(3);
            b = [3; 4; 1];
            testCase.verifyEqual(solve(A,b),b);
        end

        function testTwo(testCase)
            A = [1e-100 0; 0 1e100];
            b = [5; 5];
            expX = [5e100 5e-100];
            testCase.verifyEqual(solve(A,b),expX);
        end
    end
end