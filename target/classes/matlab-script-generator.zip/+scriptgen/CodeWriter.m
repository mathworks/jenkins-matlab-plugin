classdef CodeWriter < handle
    % CodeWriter - Writes code objects in to code
    
    % Copyright 2020 The MathWorks, Inc.
    
    properties (Access = private)
        OutputStream
    end
    
    methods
        function obj = CodeWriter(stream)
            validateattributes(stream, {'scriptgen.OutputStream'}, {'scalar'});
            obj.OutputStream = stream;
        end
        
        function writeExpression(obj, expression)
            expression.write(obj);
        end
        
        function writeStatement(obj, statement)
            statement.write(obj);
            obj.write('\n');
        end
        
        function writeSequence(obj, sequence)
            sequence.write(obj);
            obj.write('\n');
        end
        
        function writeScript(obj, script)
            script.write(obj);
        end
        
        function close(obj)
            obj.OutputStream.close();
        end
    end
    
    methods (Access = {?scriptgen.Expression, ?scriptgen.Statement})
        function write(obj, format, varargin)
            text = sprintf(format, varargin{:});
            obj.OutputStream.write(text);
        end
    end
end

