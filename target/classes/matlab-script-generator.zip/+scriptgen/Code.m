classdef Code < matlab.mixin.Heterogeneous
    % Code - Base class for all classes writable by CodeWriter
    
    % Copyright 2020 The MathWorks, Inc.
    
    methods (Abstract, Access={?scriptgen.CodeWriter, ?scriptgen.Code})
        write(obj, writer)
    end
    
    methods (Static, Sealed, Access = protected)
       function builder = getDefaultScalarElement()
           builder = scriptgen.internal.MissingCode();
       end
    end
end

