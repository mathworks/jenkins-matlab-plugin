classdef TrimmedStackException < MException
    %  Copyright 2020 MathWorks, Inc.
    
    properties(SetAccess=immutable, GetAccess=protected)
        TrimmedStack
    end
    
    methods
        function trimmed = TrimmedStackException(other, ntrim)
            trimmed = trimmed@MException(other.identifier, '%s', other.message);
            if isprop(trimmed, 'type') && isprop(other, 'type')
                trimmed.type = other.type;
            end
            for idx = 1:numel(other.cause)
                trimmed = trimmed.addCause(other.cause{idx});
            end
            stack = other.getStack();
            trimmed.TrimmedStack = stack(1:end-ntrim);
        end
    end
    
    methods(Access=protected)
        function stack = getStack(trimmed)
            stack = trimmed.TrimmedStack;
        end
    end
end


