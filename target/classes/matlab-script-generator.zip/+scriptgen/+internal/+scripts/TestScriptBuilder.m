classdef TestScriptBuilder < scriptgen.scripts.TestScriptBuilder ...
        & scriptgen.internal.mixin.VersionDependent
    % Copyright 2020 The MathWorks, Inc.
    
    properties (Constant, Access = protected)
        MinSupportedVersion = scriptgen.internal.Version.forRelease('R2013a')
    end
    
    methods
        function script = build(obj)
            import scriptgen.Script;
            import scriptgen.Sequence;
            
            testCodeProvider = obj.CodeProvider.withSubpackage('test');
            
            suiteName = 'suite';
            runnerName = 'runner';
            resultsName = 'results';
            
            sequences = Sequence.empty();
            
            if ~isempty(obj.WorkingFolder)
                sequences(end+1) = Sequence(sprintf('cd(''%s'');', obj.WorkingFolder));
            end
            
            sequences = [sequences obj.buildAddpathSequence()];
            
            sequences(end+1) = testCodeProvider.createSequence('CreateTestSuite', ...
                'CodeProvider', obj.CodeProvider, ...
                'SuiteName', suiteName);
            
            sequences = [sequences obj.buildMkdirSequence()];
            
            source = obj.SourceFolder;
            if isempty(source)
                source = '.';
            end
            
            sequences(end+1) = testCodeProvider.createSequence('CreateTestRunner', ...
                'CodeProvider', obj.CodeProvider, ...
                'RunnerName', runnerName, ...
                'PDFTestReport', quote(obj.PDFTestReport), ...
                'TAPTestResults', quote(obj.TAPTestResults), ...
                'JUnitTestResults', quote(obj.JUnitTestResults), ...
                'SimulinkTestResults', quote(obj.SimulinkTestResults), ...
                'CoberturaCodeCoverage', quote(obj.CoberturaCodeCoverage), ...
                'CoberturaModelCoverage', quote(obj.CoberturaModelCoverage), ...
                'SourceFolder', quoteCell(splitPath(source)));
            
            sequences(end+1) = Sequence( ...
                sprintf('%s = %s.run(%s);', resultsName, runnerName, suiteName));
            
            sequences(end+1) = testCodeProvider.createSequence('AssertNoFailures', ...
                'CodeProvider', obj.CodeProvider, ...
                'ResultsName', resultsName);
            
            script = Script(sequences);
        end
    end
    
    methods (Access = private)
        function s = buildAddpathSequence(obj)
            import scriptgen.Sequence;
            
            dirs = splitPath(obj.SourceFolder);
            
            if isempty(dirs)
                s = Sequence.empty();
                return;
            end
            
            for i = numel(dirs):-1:1
                code{i} = sprintf('addpath(genpath(''%s''));', dirs{i});
            end
            s = Sequence(code);
        end
        
        function s = buildMkdirSequence(obj)
            import scriptgen.Sequence;
            
            dirs = cellfun(@(f)fileparts(f), { ...
                obj.PDFTestReport, ...
                obj.TAPTestResults, ...
                obj.JUnitTestResults, ...
                obj.SimulinkTestResults, ...
                obj.CoberturaCodeCoverage, ...
                obj.CoberturaModelCoverage}, ...
                'UniformOutput', false);
            dirs = dirs(~cellfun(@isempty, dirs));
            dirs = unique(dirs);
            
            if isempty(dirs)
                s = Sequence.empty();
                return;
            end
            
            for i = numel(dirs):-1:1
                code{i} = sprintf('[~,~] = mkdir(''%s'');', dirs{i});
            end
            s = Sequence(code);
        end
    end
end

function text = splitPath(text)
if iscellstr(text) %#ok<ISCLSTR>
    return;
elseif isempty(text)
    text = {};
else
    text = strtrim(strsplit(text, {';', ':'}));
end
end

function text = quote(text)
if isempty(text)
    return;
end
text = ['''' text ''''];
end

function text = quoteCell(text)
text = cellfun(@(t)['''' t ''''], text, 'UniformOutput', false);
end