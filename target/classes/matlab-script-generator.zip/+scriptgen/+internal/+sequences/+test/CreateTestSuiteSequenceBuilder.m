classdef CreateTestSuiteSequenceBuilder < scriptgen.sequences.test.CreateTestSuiteSequenceBuilder ...
        & scriptgen.internal.mixin.VersionDependent
    % Copyright 2020 The MathWorks, Inc.
    
    properties (Constant, Access = protected)
        MinSupportedVersion = scriptgen.internal.Version.forRelease('R2013a')
    end
    
    methods
        function sequence = build(obj)
            import scriptgen.Sequence;
            
            testCodeProvider = obj.CodeProvider.withSubpackage('test');
            
            statements = testCodeProvider.createStatement('CreateTestSuite', ...
                'SuiteName', obj.SuiteName);
            
            sequence = Sequence(statements);
        end
    end
end

