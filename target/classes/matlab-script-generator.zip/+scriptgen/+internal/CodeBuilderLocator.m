classdef CodeBuilderLocator
    % CodeBuilderLocator - Locator of CodeBuilder metaclasses
    
    % Copyright 2020 The MathWorks, Inc.
    
    properties (Access = private)
        ImplementationPackage
        InterfacePackage
    end
    
    methods
        function obj = CodeBuilderLocator(implPackage, intfPackage)
            if ischar(implPackage)
                implPackage = meta.package.fromName(implPackage);
            end
            if ischar(intfPackage)
                intfPackage = meta.package.fromName(intfPackage);
            end
            obj.ImplementationPackage = implPackage;
            obj.InterfacePackage = intfPackage;
        end
        
        function metaclasses = locate(obj, type)
            if ischar(type)
                type = prependPrefix([obj.InterfacePackage.Name '.'], type);
                type = meta.class.fromName(type);
            end
            if isempty(type)
                metaclasses = type;
                return;
            end
            classes = obj.ImplementationPackage.ClassList;
            classes = classes(classes <= type);
            classes = classes(~[classes.Abstract]);
            metaclasses = classes;
        end
    end
end

function name = prependPrefix(prefix, name)
    if isempty(regexp(name, ['^' prefix '\w*'], 'once'))
        name = [prefix name];
    end
end

