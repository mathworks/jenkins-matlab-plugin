classdef Script < scriptgen.Code
    % Script - A collection of statements organized in to sequences
    
    % Copyright 2020 The MathWorks, Inc.
    
    properties (SetAccess = immutable)
        Sequences
    end
    
    methods
        function obj = Script(sequences)
            import scriptgen.Sequence;
            
            if iscellstr(sequences) || (ischar(sequences) && isvector(sequences)) %#ok<ISCLSTR>
                sequences = Sequence(sequences);
            end
            
            validateattributes(sequences, {'scriptgen.Sequence'}, {'vector'});
            
            obj.Sequences = sequences;
        end
        
        function file = writeToFile(obj, file)
            import scriptgen.FileOutput;
            [~,~] = mkdir(fileparts(file));
            stream = FileOutput(file);
            obj.writeToStream(stream);
        end
        
        function text = writeToText(obj)
            import scriptgen.TextOutput;
            stream = TextOutput();
            obj.writeToStream(stream);
            text = stream.Text;
        end
        
        function run(obj)
            tempFolder = tempname();
            [~, script] = fileparts(tempFolder);
            scriptPath = fullfile(tempFolder, [script '.m']);
            
            obj.writeToFile(scriptPath);
            oldPath = addpath(tempFolder);
            
            restoreState = onCleanup(@()cleanup(oldPath, tempFolder));
            function cleanup(p, f)
                path(p);
                rmdir(f, 's');
            end
            
            try
                evalin('caller', strcat(script, ';'));
            catch e
                throw(scriptgen.internal.TrimmedStackException(e, 2));
            end
        end
    end
    
    methods (Access = private)
        function writeToStream(obj, stream)
            import scriptgen.CodeWriter;
            writer = CodeWriter(stream);
            close = onCleanup(@()writer.close());
            writer.writeScript(obj);
        end
    end
    
    methods (Access={?scriptgen.CodeWriter, ?scriptgen.Code})
        function write(obj, writer)
            import scriptgen.Sequence;
            import scriptgen.Statement;
            
            imports = sort(unique([obj.Sequences.RequiredImports]));
            if ~isempty(imports)
                importText = cellfun(@(i)sprintf('import %s;', i), imports, 'UniformOutput', false);
                writer.writeSequence(Sequence(importText));
            end
            
            for sequence = obj.Sequences
                writer.writeSequence(sequence);
            end
        end
    end
end